﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using pr1.Models;
using System.Security.Claims;

namespace pr1.Controllers
{
    public class AccountController : Controller
    {
        private readonly Db33Context _db;

        public AccountController(Db33Context context)
        {
            _db = context;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View("~/Views/Account/Login.cshtml");
        }

        [HttpPost]
        public async Task<IActionResult> Login(string email, string password)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                ModelState.AddModelError("", "Email и пароль обязательны");
                return View("~/Views/Account/Login.cshtml");
            }


            var user = await _db.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null)
            {
                ModelState.AddModelError("", "Пользователь не найден");
                return View("~/Views/Account/Login.cshtml");
            }

            if (!user.IsActive)
            {
                ModelState.AddModelError("", "Пользователь заблокирован");
                return View("~/Views/Account/Login.cshtml");
            }

            bool isValid = false;
            try
            {
                isValid = BCrypt.Net.BCrypt.Verify(password, user.PasswordUser);
            }
            catch
            {
                isValid = false;
            }

            if (!isValid)
            {
                ModelState.AddModelError("", "Неверный пароль");
                return View("~/Views/Account/Login.cshtml");
            }

            string role = user.RoleId == 1 ? "Admin" : "User";

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.IdUser.ToString()),
                new Claim(ClaimTypes.Name, user.LoginUser),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, role)
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            System.Diagnostics.Debug.WriteLine("Signing in user: " + user.LoginUser + " role: " + role);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, new AuthenticationProperties
            {
                IsPersistent = true,
                ExpiresUtc = DateTimeOffset.UtcNow.AddDays(7)
            });

            HttpContext.Session.SetInt32("UserId", user.IdUser);

            if (role == "Admin")
            {
                return RedirectToAction("Index", "Admin"); 
            }
            else
            {
                return RedirectToAction("Index", "Products");
            }
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View("~/Views/Account/Register.cshtml");
        }

        [HttpPost]
        public async Task<IActionResult> Register(string loginUser, string email, string password)
        {
            if (string.IsNullOrEmpty(loginUser) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                ModelState.AddModelError("", "Все поля обязательны");
                return View("~/Views/Account/Register.cshtml");
            }

            if (await _db.Users.AnyAsync(u => u.Email == email))
            {
                ModelState.AddModelError("", "Пользователь с таким email уже существует");
                return View("~/Views/Account/Register.cshtml");
            }

            if (await _db.Users.AnyAsync(u => u.LoginUser == loginUser))
            {
                ModelState.AddModelError("", "Пользователь с таким логином уже существует");
                return View("~/Views/Account/Register.cshtml");
            }

            string hash = BCrypt.Net.BCrypt.HashPassword(password);

            var user = new User
            {
                LoginUser = loginUser,
                Email = email,
                PasswordUser = hash,
                RoleId = 2,                 
                IsActive = true,
                RegistrationDate = DateTime.Now
            };

            _db.Users.Add(user);
            await _db.SaveChangesAsync();

            return RedirectToAction("Login");
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        public IActionResult AccessDenied()
        {
            return View("~/Views/Account/AccessDenied.cshtml");
        }
    }
}