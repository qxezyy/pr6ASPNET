﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using pr1.Models;
using System.Linq;

[Authorize]
public class CartController : Controller
{
    private readonly Db33Context _db;

    public CartController(Db33Context context)
    {
        _db = context;
    }

    public IActionResult Index()
    {
        int? userId = HttpContext.Session.GetInt32("UserId");
        if (userId == null)
            return RedirectToAction("Login", "Account");

        var cart = _db.Carts.FirstOrDefault(c => c.UuserId == userId.Value);
        if (cart == null)
            return View(new List<CartItemViewModel>());

        var cartItems = _db.CartItems.Where(ci => ci.CartId == cart.IdCart).ToList();
        var productIds = cartItems.Select(ci => ci.ProductId).ToList();
        var products = _db.Products.Where(p => productIds.Contains(p.IdProduct))
                                   .ToDictionary(p => p.IdProduct);

        var viewModel = cartItems.Select(ci => new CartItemViewModel
        {
            IdCartitem = ci.IdCartitem,
            ProductId = ci.ProductId,
            ProductTitle = products[ci.ProductId].Title,
            Price = products[ci.ProductId].Price,
            Quantity = ci.Quantity,
            Total = ci.Quantity * products[ci.ProductId].Price
        }).ToList();

        return View(viewModel);
    }

    [HttpPost]
    public IActionResult UpdateQuantity(int cartItemId, int quantity)
    {
        var item = _db.CartItems.Find(cartItemId);
        if (item != null)
        {
            if (quantity <= 0)
                _db.CartItems.Remove(item);
            else
                item.Quantity = quantity;
            _db.SaveChanges();
        }
        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Remove(int cartItemId)
    {
        var item = _db.CartItems.Find(cartItemId);
        if (item != null)
        {
            _db.CartItems.Remove(item);
            _db.SaveChanges();
        }
        return RedirectToAction("Index");
    }
}