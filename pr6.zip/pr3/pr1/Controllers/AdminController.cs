using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using pr1.Helpers;
using pr1.Models;

namespace pr1.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly Db33Context _db;

        public AdminController(Db33Context context)
        {
            _db = context;
        }

        public IActionResult Index()
        {
            return View("~/Views/Admin/Index.cshtml");
        }

        public async Task<IActionResult> Roles()
        {
            var roles = await _db.Roles.ToListAsync();
            return View("~/Views/Admin/Roles/Index.cshtml", roles);
        }

        public IActionResult CreateRole()
        {
            return View("~/Views/Admin/Roles/Create.cshtml");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateRole([Bind("Title")] Role role)
        {
            if (ModelState.IsValid)
            {
                _db.Add(role);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Roles));
            }
            return View("~/Views/Admin/Roles/Create.cshtml", role);
        }

        public async Task<IActionResult> EditRole(int? id)
        {
            if (id == null) return NotFound();
            var role = await _db.Roles.FindAsync(id);
            if (role == null) return NotFound();
            return View("~/Views/Admin/Roles/Edit.cshtml", role);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditRole(int id, [Bind("IdRole,Title")] Role role)
        {
            if (id != role.IdRole) return NotFound();
            if (ModelState.IsValid)
            {
                try
                {
                    _db.Update(role);
                    await _db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RoleExists(role.IdRole)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Roles));
            }
            return View("~/Views/Admin/Roles/Edit.cshtml", role);
        }

        public async Task<IActionResult> DeleteRole(int? id)
        {
            if (id == null) return NotFound();
            var role = await _db.Roles.FindAsync(id);
            if (role == null) return NotFound();
            return View("~/Views/Admin/Roles/Delete.cshtml", role);
        }

        [HttpPost, ActionName("DeleteRole")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteRoleConfirmed(int id)
        {
            var role = await _db.Roles.FindAsync(id);
            if (role != null)
            {
                _db.Roles.Remove(role);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Roles));
        }

        private bool RoleExists(int id) => _db.Roles.Any(e => e.IdRole == id);

        public async Task<IActionResult> Users()
        {
            var users = await _db.Users.ToListAsync();
            var roles = await _db.Roles.ToDictionaryAsync(r => r.IdRole, r => r.Title);
            ViewBag.RoleNames = roles;
            return View("~/Views/Admin/Users/Index.cshtml", users);
        }

        public IActionResult CreateUser()
        {
            ViewBag.Roles = new SelectList(_db.Roles, "IdRole", "Title");
            return View("~/Views/Admin/Users/Create.cshtml", new UserCreateViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateUser(UserCreateViewModel model)
        {

            if (!ModelState.IsValid)
            {
                ViewBag.Roles = new SelectList(_db.Roles, "IdRole", "Title", model.RoleId);
                return View("~/Views/Admin/Users/Create.cshtml", model);
            }
            var user = new User
            {
                LoginUser = model.LoginUser,
                PasswordUser = PasswordHelper.HashPassword(model.PlainPassword),
                Email = model.Email,
                RoleId = model.RoleId,
                RegistrationDate = DateTime.Now
            };
            _db.Add(user);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Users));
        }

        public async Task<IActionResult> EditUser(int? id)
        {
            if (id == null) return NotFound();
            var user = await _db.Users.FindAsync(id);
            if (user == null) return NotFound();
            ViewBag.Roles = new SelectList(_db.Roles, "IdRole", "Title", user.RoleId);
            return View("~/Views/Admin/Users/Edit.cshtml", user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditUser(int id, User user, string? plainPassword)
        {
            if (id != user.IdUser) return NotFound();
            if (ModelState.IsValid)
            {
                try
                {
                    if (!string.IsNullOrEmpty(plainPassword))
                    {
                        user.PasswordUser = PasswordHelper.HashPassword(plainPassword);
                    }
                    else
                    {
                        var existingUser = await _db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.IdUser == id);
                        user.PasswordUser = existingUser.PasswordUser;
                    }
                    _db.Update(user);
                    await _db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserExists(user.IdUser)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Users));
            }
            ViewBag.Roles = new SelectList(_db.Roles, "IdRole", "Title", user.RoleId);
            return View("~/Views/Admin/Users/Edit.cshtml", user);
        }

        public async Task<IActionResult> DeleteUser(int? id)
        {
            if (id == null) return NotFound();
            var user = await _db.Users.FindAsync(id);
            if (user == null) return NotFound();
            var role = await _db.Roles.FindAsync(user.RoleId);
            ViewBag.RoleTitle = role?.Title ?? "����������� ����";
            return View("~/Views/Admin/Users/Delete.cshtml", user);
        }

        [HttpPost, ActionName("DeleteUser")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteUserConfirmed(int id)
        {
            var user = await _db.Users.FindAsync(id);
            if (user != null)
            {
                _db.Users.Remove(user);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Users));
        }

        private bool UserExists(int id) => _db.Users.Any(e => e.IdUser == id);


        public async Task<IActionResult> Categories()
        {
            var categories = await _db.Categories.ToListAsync();
            return View("~/Views/Admin/Categories/Index.cshtml", categories);
        }

        public IActionResult CreateCategory()
        {
            return View("~/Views/Admin/Categories/Create.cshtml");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateCategory([Bind("Title")] Category category)
        {
            if (ModelState.IsValid)
            {
                _db.Add(category);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Categories));
            }
            return View("~/Views/Admin/Categories/Create.cshtml", category);
        }

        public async Task<IActionResult> EditCategory(int? id)
        {
            if (id == null) return NotFound();
            var category = await _db.Categories.FindAsync(id);
            if (category == null) return NotFound();
            return View("~/Views/Admin/Categories/Edit.cshtml", category);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditCategory(int id, [Bind("IdCategory,Title")] Category category)
        {
            if (id != category.IdCategory) return NotFound();
            if (ModelState.IsValid)
            {
                try
                {
                    _db.Update(category);
                    await _db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CategoryExists(category.IdCategory)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Categories));
            }
            return View(category);
        }

        public async Task<IActionResult> DeleteCategory(int? id)
        {
            if (id == null) return NotFound();
            var category = await _db.Categories.FindAsync(id);
            if (category == null) return NotFound();
            return View("~/Views/Admin/Categories/Delete.cshtml", category);
        }

        [HttpPost, ActionName("DeleteCategory")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteCategoryConfirmed(int id)
        {
            var category = await _db.Categories.FindAsync(id);
            if (category != null)
            {
                _db.Categories.Remove(category);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Categories));
        }

        private bool CategoryExists(int id) => _db.Categories.Any(e => e.IdCategory == id);
        public async Task<IActionResult> Products()
        {
            var products = await _db.Products.ToListAsync();
            var categories = await _db.Categories.ToDictionaryAsync(c => c.IdCategory, c => c.Title);
            ViewBag.CategoryNames = categories;
            return View("~/Views/Admin/Products/Index.cshtml", products);
        }

        public IActionResult CreateProduct()
        {
            ViewBag.Categories = new SelectList(_db.Categories, "IdCategory", "Title");
            return View("~/Views/Admin/Products/Create.cshtml");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateProduct([Bind("Title,Price,CategoryId,DescriptionProduct,RegistrationDate")] Product product)
        {
            if (ModelState.IsValid)
            {
                _db.Add(product);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Products));
            }
            ViewBag.Categories = new SelectList(_db.Categories, "IdCategory", "Title", product.CategoryId);
            return View("~/Views/Admin/Products/Create.cshtml", product);
        }

        public async Task<IActionResult> EditProduct(int? id)
        {
            if (id == null) return NotFound();
            var product = await _db.Products.FindAsync(id);
            if (product == null) return NotFound();
            ViewBag.Categories = new SelectList(_db.Categories, "IdCategory", "Title", product.CategoryId);
            return View("~/Views/Admin/Products/Edit.cshtml", product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditProduct(int id, [Bind("IdProduct,Title,Price,CategoryId,DescriptionProduct,RegistrationDate")] Product product)
        {
            if (id != product.IdProduct) return NotFound();
            if (ModelState.IsValid)
            {
                try
                {
                    _db.Update(product);
                    await _db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(product.IdProduct)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Products));
            }
            ViewBag.Categories = new SelectList(_db.Categories, "IdCategory", "Title", product.CategoryId);
            return View("~/Views/Admin/Products/Edit.cshtml", product);
        }

        public async Task<IActionResult> DeleteProduct(int? id)
        {
            if (id == null) return NotFound();
            var product = await _db.Products.FindAsync(id);
            if (product == null) return NotFound();
            var category = await _db.Categories.FindAsync(product.CategoryId);
            ViewBag.CategoryTitle = category?.Title;
            return View("~/Views/Admin/Products/Delete.cshtml", product);
        }

        [HttpPost, ActionName("DeleteProduct")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteProductConfirmed(int id)
        {
            var product = await _db.Products.FindAsync(id);
            if (product != null)
            {
                _db.Products.Remove(product);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Products));
        }

        private bool ProductExists(int id) => _db.Products.Any(e => e.IdProduct == id);

        public async Task<IActionResult> Carts()
        {
            var carts = await _db.Carts.ToListAsync();
            var users = await _db.Users.ToDictionaryAsync(u => u.IdUser, u => u.LoginUser);
            ViewBag.UserNames = users;
            return View("~/Views/Admin/Carts/Index.cshtml", carts);
        }

        public async Task<IActionResult> CartDetails(int? id)
        {
            if (id == null) return NotFound();
            var cart = await _db.Carts.FindAsync(id);
            if (cart == null) return NotFound();

            var user = await _db.Users.FindAsync(cart.UuserId);
            ViewBag.UserName = user?.LoginUser;

            var items = await _db.CartItems.Where(ci => ci.CartId == id).ToListAsync();
            ViewBag.CartItems = items;

            var productIds = items.Select(i => i.ProductId).Distinct();
            var products = await _db.Products.Where(p => productIds.Contains(p.IdProduct)).ToDictionaryAsync(p => p.IdProduct);
            ViewBag.Products = products;

            return View("~/Views/Admin/Carts/Details.cshtml", cart);
        }

        [HttpPost, ActionName("DeleteCart")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteCartConfirmed(int id)
        {
            var cart = await _db.Carts.FindAsync(id);
            if (cart != null)
            {
                _db.Carts.Remove(cart);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Carts));
        }

        public async Task<IActionResult> Orders()
        {
            var orders = await _db.Orders.ToListAsync();
            var users = await _db.Users.ToDictionaryAsync(u => u.IdUser, u => u.LoginUser);
            ViewBag.UserNames = users;
            return View("~/Views/Admin/Orders/Index.cshtml", orders);
        }

        public async Task<IActionResult> OrderDetails(int? id)
        {
            if (id == null) return NotFound();
            var order = await _db.Orders.FindAsync(id);
            if (order == null) return NotFound();

            var user = await _db.Users.FindAsync(order.UuserId);
            ViewBag.UserName = user?.LoginUser;

            var items = await _db.OrderItems.Where(oi => oi.OrderId == id).ToListAsync();
            ViewBag.OrderItems = items;

            return View("~/Views/Admin/Orders/Details.cshtml", order);
        }

        public async Task<IActionResult> EditOrder(int? id)
        {
            if (id == null) return NotFound();
            var order = await _db.Orders.FindAsync(id);
            if (order == null) return NotFound();
            ViewBag.Statuses = new SelectList(new[] { "��������", "���������", "�������" }, order.StatusOrder);
            return View("~/Views/Admin/Orders/Edit.cshtml", order);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditOrder(int id, [Bind("IdOrder,StatusOrder,DeliveryAddress")] Order order)
        {
            if (id != order.IdOrder) return NotFound();
            if (ModelState.IsValid)
            {
                try
                {
                    var existingOrder = await _db.Orders.FindAsync(id);
                    existingOrder.StatusOrder = order.StatusOrder;
                    existingOrder.DeliveryAddress = order.DeliveryAddress;
                    await _db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OrderExists(order.IdOrder)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Orders));
            }
            ViewBag.Statuses = new SelectList(new[] { "��������", "���������", "�������" }, order.StatusOrder);
            return View(order);
        }

        private bool OrderExists(int id) => _db.Orders.Any(e => e.IdOrder == id);

        [HttpPost, ActionName("DeleteOrder")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteOrderConfirmed(int id)
        {
            var order = await _db.Orders.FindAsync(id);
            if (order != null)
            {
                _db.Orders.Remove(order);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Orders));
        }
    }
}