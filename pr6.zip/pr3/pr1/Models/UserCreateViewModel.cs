﻿using pr1.ValidationAttributes;
using System.ComponentModel.DataAnnotations;

namespace pr1.Models
{
    public class UserCreateViewModel
    {
        [Required(ErrorMessage = "Логин обязателен")]
        [NoAdminName]
        [LoginMinLength]
        public string LoginUser { get; set; }

        [Required(ErrorMessage = "Пароль обязателен")]
        [PasswordDigit]
        public string PlainPassword { get; set; }

        [Required(ErrorMessage = "Email обязателен")]
        [EmailAddress(ErrorMessage = "Некорректный email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Выберите роль")]
        public int RoleId { get; set; }
    }
}