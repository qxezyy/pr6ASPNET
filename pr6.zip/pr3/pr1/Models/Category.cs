﻿using System;
using System.Collections.Generic;

namespace pr1.Models;

public partial class Category
{
    public int IdCategory { get; set; }

    public string Title { get; set; } = null!;
}
