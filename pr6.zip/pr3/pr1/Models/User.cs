﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using pr1.ValidationAttributes;
using System.ComponentModel.DataAnnotations;

namespace pr1.Models;

public partial class User
{
    public int IdUser { get; set; }

    [Column("login_user")]
    public string LoginUser { get; set; }
    public string PasswordUser { get; set; } = null!;
    public int RoleId { get; set; }
    public string? Email { get; set; }

    public bool IsActive { get; set; } = true;
    public DateTime RegistrationDate { get; set; }
}
