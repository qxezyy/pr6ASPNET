﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace pr1.Models;

public partial class Db33Context : DbContext
{
    public Db33Context()
    {
    }

    public Db33Context(DbContextOptions<Db33Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Cart> Carts { get; set; }

    public virtual DbSet<CartItem> CartItems { get; set; }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<Order> Orders { get; set; }

    public virtual DbSet<OrderItem> OrderItems { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=WIN-8TFLCUJN53E\\SQLEXPRESS;Initial Catalog=DB33;Integrated Security=True;Trust Server Certificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Cart>(entity =>
        {
            entity.HasKey(e => e.IdCart).HasName("PK__Carts__701794904C46A7E8");

            entity.HasIndex(e => e.UuserId, "UQ__Carts__6585BE62CCD57834").IsUnique();

            entity.Property(e => e.IdCart).HasColumnName("ID_cart");
            entity.Property(e => e.CreationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("creation_date");
            entity.Property(e => e.UpdateDate).HasColumnName("update_date");
            entity.Property(e => e.UuserId).HasColumnName("uuser_ID");

      
        });

        modelBuilder.Entity<CartItem>(entity =>
        {
            entity.HasKey(e => e.IdCartitem).HasName("PK__CartItem__813AB3A1B2B6C42B");

            entity.HasIndex(e => new { e.CartId, e.ProductId }, "UQ_cart_item").IsUnique();

            entity.Property(e => e.IdCartitem).HasColumnName("ID_cartitem");
            entity.Property(e => e.CartId).HasColumnName("cart_ID");
            entity.Property(e => e.ProductId).HasColumnName("product_ID");
            entity.Property(e => e.Quantity).HasColumnName("quantity");

         
        });

        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasKey(e => e.IdCategory).HasName("PK__Categori__AC5CA40E02A4F474");

            entity.HasIndex(e => e.Title, "UQ__Categori__E52A1BB35B17C1F5").IsUnique();

            entity.Property(e => e.IdCategory).HasColumnName("ID_category");
            entity.Property(e => e.Title)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("title");
        });

        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(e => e.IdOrder).HasName("PK__Orders__89BFCD59AE5EC837");

            entity.Property(e => e.IdOrder).HasColumnName("ID_order");
            entity.Property(e => e.DeliveryAddress)
                .HasMaxLength(70)
                .IsUnicode(false)
                .HasColumnName("delivery_address");
            entity.Property(e => e.OrderDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("order_date");
            entity.Property(e => e.StatusOrder)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Ожидание")
                .HasColumnName("status_order");
            entity.Property(e => e.Totalamount)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("totalamount");
            entity.Property(e => e.UuserId).HasColumnName("uuser_ID");

         
        });

        modelBuilder.Entity<OrderItem>(entity =>
        {
            entity.HasKey(e => e.IdOrderitem).HasName("PK__OrderIte__14046CD2BB69403C");

            entity.Property(e => e.IdOrderitem).HasColumnName("ID_orderitem");
            entity.Property(e => e.OrderId).HasColumnName("order_ID");
            entity.Property(e => e.Price)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("price");
            entity.Property(e => e.ProductId).HasColumnName("product_ID");
            entity.Property(e => e.Quantity).HasColumnName("quantity");
            entity.Property(e => e.Title)
                .HasMaxLength(70)
                .IsUnicode(false)
                .HasColumnName("title");

           
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.IdProduct).HasName("PK__Products__FD7FEC23E985FEF5");

            entity.Property(e => e.IdProduct).HasColumnName("ID_product");
            entity.Property(e => e.CategoryId).HasColumnName("category_ID");
            entity.Property(e => e.DescriptionProduct)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("description_product");
            entity.Property(e => e.Price)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("price");
            entity.Property(e => e.RegistrationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("registration_date");
            entity.Property(e => e.Title)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("title");

          
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.IdRole).HasName("PK__Roles__45DFFBDB0885F8F7");

            entity.HasIndex(e => e.Title, "UQ__Roles__E52A1BB34162CEC4").IsUnique();

            entity.Property(e => e.IdRole).HasColumnName("ID_role");
            entity.Property(e => e.Title)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("title");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.IdUser).HasName("PK__Users__D7B4671E9198948B");

            entity.HasIndex(e => e.LoginUser, "UQ__Users__12D0D37FA49DAB51").IsUnique();

            entity.Property(e => e.IdUser).HasColumnName("ID_user");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("email");
            entity.Property(e => e.LoginUser)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("login_user");
            entity.Property(e => e.PasswordUser)
                .HasMaxLength(128)
                .IsUnicode(false)
                .IsFixedLength()
                .HasColumnName("password_user");
            entity.Property(e => e.RegistrationDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("registration_date");
            entity.Property(e => e.RoleId).HasColumnName("role_ID");

           
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
