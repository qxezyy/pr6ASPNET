﻿using System;
using System.Collections.Generic;

namespace pr1.Models;

public partial class OrderItem
{
    public int IdOrderitem { get; set; }

    public int OrderId { get; set; }

    public int ProductId { get; set; }

    public string Title { get; set; } = null!;

    public decimal Price { get; set; }

    public int Quantity { get; set; }
}
