﻿using System.ComponentModel.DataAnnotations;
namespace pr1.ValidationAttributes
{
    public class PositivePriceAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
                return ValidationResult.Success;

            decimal price = (decimal)value;
            if (price <= 0)
                return new ValidationResult("Цена должна быть положительным числом.");

            return ValidationResult.Success;
        }
    }
}