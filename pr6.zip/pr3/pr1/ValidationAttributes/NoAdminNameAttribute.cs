﻿using System.ComponentModel.DataAnnotations;
namespace pr1.ValidationAttributes
{
    public class NoAdminNameAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
                return ValidationResult.Success;

            string login = value.ToString();
            if (login.ToLower() == "admin")
                return new ValidationResult("Логин 'admin' запрещён.");

            return ValidationResult.Success;
        }
    }
}