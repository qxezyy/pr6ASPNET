﻿using System.Security.Cryptography;
using System.Text;

namespace pr1.Helpers
{
    /// <summary>
    /// Вспомогательный класс для хеширования и проверки паролей
    /// с использованием соли и SHA-256.
    /// </summary>
    public static class PasswordHelper
    {
        /// <summary>
        /// Создаёт хеш пароля с солью.
        /// Возвращает строку длиной 128 символов: первые 64 — соль, оставшиеся 64 — хеш.
        /// </summary>
        public static string HashPassword(string plainPassword)
        {
            string salt = GenerateSalt();                         // 64 символа
            string salted = plainPassword + salt;                 // пароль + соль
            string hash = ComputeSha256Hash(salted);              // 64 символа (hex)
            return salt + hash;                                   // итого 128 символов
        }

        /// <summary>
        /// Проверяет, соответствует ли введённый пароль сохранённому хешу.
        /// storedHash должен иметь формат: первые 64 символа — соль, остальные — хеш.
        /// </summary>
        public static bool VerifyPassword(string plainPassword, string storedHash)
        {
            if (string.IsNullOrEmpty(storedHash) || storedHash.Length != 128)
                return false;

            string salt = storedHash.Substring(0, 64);            // извлекаем соль
            string expectedHash = storedHash.Substring(64);       // ожидаемый хеш
            string salted = plainPassword + salt;                 // солим введённый пароль
            string computedHash = ComputeSha256Hash(salted);      // вычисляем хеш
            return computedHash == expectedHash;
        }

        /// <summary>
        /// Генерирует криптографическую соль длиной 64 символа (hex).
        /// </summary>
        private static string GenerateSalt()
        {
            // Используем Guid для получения случайных данных
            string guid = Guid.NewGuid().ToString();
            return ComputeSha256Hash(guid);
        }

        /// <summary>
        /// Вычисляет SHA-256 хеш строки и возвращает его в виде hex-строки (64 символа).
        /// </summary>
        private static string ComputeSha256Hash(string input)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
                return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            }
        }
    }
}